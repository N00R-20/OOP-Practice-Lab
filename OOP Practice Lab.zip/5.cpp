#include<iostream>
using namespace std;

class Animal
{
public:
   void eat(){ cout<<"Animal Eats\n"; }
};

class Dog: public Animal
{
public:
   void bark(){ cout<<"Dog Barks\n"; }
};

class Puppy: public Dog
{
public:
   void weep(){ cout<<"Puppy Weeps\n"; }
};

int main()
{
   Puppy p;
   p.eat();
   p.bark();
   p.weep();
}