#include<iostream>
using namespace std;

class Animal
{
public:
   virtual void sound()
   {
       cout<<"Animal Sound\n";
   }
};

class Cat: public Animal
{
public:
   void sound()
   {
       cout<<"Meow\n";
   }
};

int main()
{
   Animal *a;
   Cat c;
   a=&c;
   a->sound();
}