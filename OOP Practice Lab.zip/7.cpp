#include<iostream>
using namespace std;

class Area
{
public:
   int calculate(int side)
   {
       return side*side;
   }

   int calculate(int length,int width)
   {
       return length*width;
   }
};

int main()
{
   Area a;
   cout<<"Square Area: "<<a.calculate(5)<<endl;
   cout<<"Rectangle Area: "<<a.calculate(5,4);
}