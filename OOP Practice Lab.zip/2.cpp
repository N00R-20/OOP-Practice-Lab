#include<iostream>
using namespace std;

class BankAccount
{
   string holder;
   float balance;

public:
   BankAccount(string h,float b)
   {
       holder=h;
       balance=b;
   }

   void display()
   {
       cout<<"Account Holder: "<<holder<<endl;
       cout<<"Balance: "<<balance<<endl;
   }
};

int main()
{
   BankAccount acc("Ali",5000);
   acc.display();
   return 0;
}