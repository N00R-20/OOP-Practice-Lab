#include<iostream>
using namespace std;

class Person
{
public:
   string name;
   int age;
};

class Student: public Person
{
public:
   int rollNo;

   void input()
   {
       cin>>name>>age>>rollNo;
   }

   void display()
   {
       cout<<name<<" "<<age<<" "<<rollNo;
   }
};

int main()
{
   Student s;
   s.input();
   s.display();
}