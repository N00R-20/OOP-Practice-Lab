#include<iostream>
using namespace std;

struct Book
{
   int id;
   string title;
   string author;
};

int main()
{
   Book b;

   cout<<"Enter Book ID: ";
   cin>>b.id;

   cout<<"Enter Title: ";
   cin>>b.title;

   cout<<"Enter Author: ";
   cin>>b.author;

   cout<<"\nBook Information\n";
   cout<<"ID: "<<b.id<<endl;
   cout<<"Title: "<<b.title<<endl;
   cout<<"Author: "<<b.author<<endl;

   return 0;
}