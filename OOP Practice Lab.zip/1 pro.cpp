#include<iostream>
using namespace std;

class Employee
{
private:
   int salary;

public:
   string name;

   void setSalary(int s)
   {
       salary=s;
   }

   void display()
   {
       cout<<"Name: "<<name<<endl;
       cout<<"Salary: "<<salary<<endl;
   }
};

int main()
{
   Employee e;
   cout<<"Enter Employee Name: ";
   cin>>e.name;

   e.setSalary(30000);
   e.display();

   return 0;
}